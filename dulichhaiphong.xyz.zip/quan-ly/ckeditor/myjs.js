CKEDITOR.replace( 'content',{
    filebrowserBrowseUrl: '/quan-ly/kcfinder/browse.php?type=files',

    filebrowserImageBrowseUrl: '/quan-ly/kcfinder/browse.php?type=images',

    filebrowserFlashBrowseUrl: '/quan-ly/kcfinder/browse.php?type=flash',

    filebrowserUploadUrl: '/quan-ly/kcfinder/upload.php?type=files',

    filebrowserImageUploadUrl: '/quan-ly/kcfinder/upload.php?type=images',

    filebrowserFlashUploadUrl: '/quan-ly/kcfinder/upload.php?type=flash',
    filebrowserUploadMethod:'form',
    height: '500px',
} );